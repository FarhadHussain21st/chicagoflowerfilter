<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://hztech.biz
 * @since      1.0.0
 *
 * @package    Customize_Flowers
 * @subpackage Customize_Flowers/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Customize_Flowers
 * @subpackage Customize_Flowers/includes
 * @author     hztech <farhad@hztech.biz>
 */
class Customize_Flowers_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
